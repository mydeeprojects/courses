# Notebooks for Lesson 02

## Description
1. Extreme_Anomaly_Detection_instructor: notebook for client
2. Extreme_Anomaly_Detection_instructor_figures: figures for PPT 

    